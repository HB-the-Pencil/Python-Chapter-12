"""
I did not feel like creating new images, etc just for this TIY, so instead
I created a new directory for this TIY. 12-2 is basically version control for
the early version of Defender.
"""

from barcalow_tiy_12_2_game_character.tiy_12_2_defendish import Defendish

if __name__ == "__main__":
    game = Defendish()
    game.run_game()