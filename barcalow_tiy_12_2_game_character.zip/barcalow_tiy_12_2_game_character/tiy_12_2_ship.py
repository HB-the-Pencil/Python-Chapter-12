import pygame
from settings import Settings

class Ship:
    """A class to manage the player ship."""

    def __init__(self, d_game):
        """
        Initialize the ship and its starting position.
        """
        self.settings = Settings()

        self.screen = d_game.screen
        self.screen_rect = d_game.screen.get_rect()

        # Import the ship images.
        self.images = {
            "ship_l_1": pygame.image.load("images/ship_l_1.png"),
            "ship_l_2": pygame.image.load("images/ship_l_2.png"),
            "ship_r_1": pygame.image.load("images/ship_r_1.png"),
            "ship_r_2": pygame.image.load("images/ship_r_2.png"),
        }

        # Define a direction and frame to draw different ship images.
        self.dir = "r"
        self.frame = "1"

        self.image = self.images[f"ship_{self.dir}_{self.frame}"]
        self.image = pygame.transform.scale(self.image,
            (self.settings.player_w, self.settings.player_h)
        )
        self.rect = self.image.get_rect()

        # Move the ship to the center of the screen.
        self.rect.center = self.screen_rect.center

    def draw(self):
        """
        Draw the ship to the screen.

        :return: Draws the ship image to the screen.
        """
        self.screen.blit(self.image, self.rect)